// * 系统全局字典

/**
 * @description：用户性别
 */
export const genderType = [
	{ label: "男", value: 1 },
	{ label: "女", value: 2 }
];

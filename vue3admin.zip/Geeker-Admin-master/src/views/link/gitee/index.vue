<template>
	<div class="content-box">
		<span class="text">
			Gitee 仓库：
			<a href="https://gitee.com/laramie/Geeker-Admin" target="_blank">https://gitee.com/laramie/Geeker-Admin</a> 🍒🍉🍊
		</span>
	</div>
</template>

<script setup lang="ts" name="gitee"></script>

<style scoped lang="scss">
@import "./index.scss";
</style>

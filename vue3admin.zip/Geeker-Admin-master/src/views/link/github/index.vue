<template>
	<div class="content-box">
		<span class="text">
			GitHub 仓库：
			<a href="https://github.com/HalseySpicy/Geeker-Admin" target="_blank">https://github.com/HalseySpicy/Geeker-Admin</a> 🍒🍉🍊
		</span>
	</div>
</template>

<script setup lang="ts" name="github"></script>

<style scoped lang="scss">
@import "./index.scss";
</style>

<template>
	<div class="content-box">
		<span class="text"> 个人博客： <a href="http://www.spicyboy.cn" target="_blank">http://www.spicyboy.cn</a> 🍒🍉🍊 </span>
	</div>
</template>

<script setup lang="ts" name="myBlog"></script>

<style scoped lang="scss">
@import "./index.scss";
</style>
